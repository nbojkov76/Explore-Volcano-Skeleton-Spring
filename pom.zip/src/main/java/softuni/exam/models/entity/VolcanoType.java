package softuni.exam.models.entity;

public enum VolcanoType {

    CINDER_CONE, STRATOVOLCANO, SHIELD_VOLCANO, LAVA_DOME, CALDERA;
}
